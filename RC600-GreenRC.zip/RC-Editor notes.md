* Always connect to some recent backup. Backup often.
* I've renamed one to be my "standard" and always connect to it first.
* Connect to and Work with that folder and keep it as your Master.
* Editor drop-downs sometime will show blank.  On the long lists, it's best to backspace a character or two in the entry field and choose from the list. Don't type it in yourself.
* Watch the looper.  It's obvious when it's connected so you can sync locations and such.
* Wait for the Editor Popup for completion of target or push sync.  
* If it is showing normal screens it's not connected even if the editor indicates you can sync.
* Switch Patches once to effect Assign changes in the looper!!!
* Test changes so as not to surprise yourself.
